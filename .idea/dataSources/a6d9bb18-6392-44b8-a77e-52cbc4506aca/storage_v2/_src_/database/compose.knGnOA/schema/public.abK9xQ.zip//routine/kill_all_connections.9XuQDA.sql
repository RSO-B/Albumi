create function kill_all_connections()
  returns text
security definer
language plpgsql
as $$
BEGIN
                EXECUTE 'SELECT pg_terminate_backend(pg_stat_activity.pid) FROM pg_stat_activity WHERE pg_stat_activity.datname = current_database() AND pid <> pg_backend_pid()';
                RETURN 'ok';
        END
$$;

alter function kill_all_connections()
  owner to focker;

